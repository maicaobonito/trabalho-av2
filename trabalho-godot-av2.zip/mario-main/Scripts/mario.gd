extends CharacterBody2D

class_name Player

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

enum PlayerMode{
	SMALL,
	BIG,
	SHOOTING
}

signal points_scored(points: int)

const POINTS_LABEL_SCENE = preload("res://Cenas/points_label.tscn")

@onready var animated_sprite_2d = $AnimatedSprite2D as PlayerAnimatedSprite
@onready var area_collision_shape_2d = $Area2D/AreaCollisionShape2D
@onready var body_collision_shape_2d = $BodyCollisionShape2D
@onready var area_2d = $Area2D
@onready var rewind_sound = $rewind
@export_group("Locomotion")
@export var run_speed_damping = 0.5
@export var speed = 67.0
@export var jump_velocity = -250
@export_group("")
@export_group("Stomping Enemies")
@export var min_stomp_degree = 35
@export var max_stomp_degree = 145
@export var stomp_y_velocity = -150
@export_group("")

@export var rewind_step_delay := 0.02  # tempo entre passos do rewind (em segundos)
var rewind_step_timer := 0.0

var is_crouching = false


var is_dead = false
var player_mode = PlayerMode.SMALL
# === Sistema de REWIND (voltar no tempo) ===
@export var rewind_duration := 3.0  # segundos que o rewind pode voltar
@export var rewind_interval := 0.1  # intervalo entre capturas de posição

var rewind_positions: Array[Vector2] = []
var rewind_timer := 0.0
var is_rewinding := false

# === Sistema de PULO DUPLO ===
var jumps_left = 2
var max_jumps = 2

func _physics_process(delta: float) -> void:
	if is_dead:
		return

	# === MODO REWIND ATIVO COM VELOCIDADE REDUZIDA ===
	if is_rewinding:
		rewind_step_timer += delta
		if rewind_step_timer >= rewind_step_delay:
			rewind_step_timer = 0.0
			if rewind_positions.size() > 0:
				global_position = rewind_positions.pop_back()
				velocity = Vector2.ZERO
			else:
				is_rewinding = false
				rewind_sound.stop()
		return

	# === GRAVIDADE ===
	if not is_on_floor():
		velocity.y += gravity * delta

	# === RESETAR PULOS AO ENCOSTAR NO CHÃO ===
	if is_on_floor():
		jumps_left = max_jumps

	# === PULO / PULO DUPLO ===
	if Input.is_action_just_pressed("jump") and jumps_left > 0:
		velocity.y = jump_velocity

		if not is_on_floor() and jumps_left == 1:
			animated_sprite_2d.play("TESTE_DOUBLEJUMP")

		jumps_left -= 1

	# === SOLTAR BOTÃO DO PULO ===
	if Input.is_action_just_released("jump") and velocity.y < 0:
		velocity.y *= 0.7

	# === DETECTAR AGACHAMENTO ===
	is_crouching = Input.is_action_pressed("down") and is_on_floor()

	# === MOVIMENTO LATERAL ===
	var direction = 0.0
	if not is_crouching:
		direction = Input.get_axis("left", "right")
		velocity.x = speed * direction
	else:
		velocity.x = 0

	# === ANIMAÇÃO ===
	animated_sprite_2d.trigger_animation(velocity, direction, player_mode, is_crouching)

	# === GRAVAR POSIÇÕES PARA O REWIND ===
	rewind_timer += delta
	if rewind_timer >= rewind_interval:
		rewind_timer = 0
		rewind_positions.append(global_position)
	if rewind_positions.size() > rewind_duration / rewind_interval:
		rewind_positions.pop_front()
	# === MOVIMENTO ===
	move_and_slide()

	# === ATIVAR REWIND COM TECLA ===
	if Input.is_action_just_pressed("rewind") and rewind_positions.size() > 0:
		is_rewinding = true
		rewind_sound.play()

	# === REWIND: GRAVAR POSIÇÕES ===
	rewind_timer += delta
	if rewind_timer >= rewind_interval:
		rewind_timer = 0
		rewind_positions.append(global_position)

	# === MOVIMENTO ===
	move_and_slide()

	# === ATIVAR REWIND COM TECLA ===
	if Input.is_action_just_pressed("rewind"):
		is_rewinding = true




func _on_area_2d_area_entered(area):
	if area is Enemy:
		handle_enemy_collision(area)

func handle_enemy_collision(enemy: Enemy):
	if enemy == null || is_dead:
		return
	
	if is_instance_of(enemy, Koopa) and (enemy as Koopa).in_a_shell:
		(enemy as Koopa).on_stomp(global_position)
	else:
		var angle_of_collision = rad_to_deg(position.angle_to_point(enemy.position))
		
		if angle_of_collision > min_stomp_degree && max_stomp_degree > angle_of_collision:
			enemy.die()
			on_enemy_stomped()
			spawn_points_label(enemy)
		else:
			die()

func on_enemy_stomped():
	velocity.y = stomp_y_velocity

func spawn_points_label(enemy):
	var points_label = POINTS_LABEL_SCENE.instantiate()
	points_label.position = enemy.position + Vector2(-20, -20)
	get_tree().root.add_child(points_label)
	points_scored.emit(100)

func die():
	if player_mode == PlayerMode.SMALL:
		is_dead = true
		animated_sprite_2d.play("TESTE_MORTE")
		set_physics_process(false)
		
		var death_tween = get_tree().create_tween()
		death_tween.tween_property(self, "position", position + Vector2(0,-48), .5)
		death_tween.chain().tween_property(self,"position", position + Vector2(0, 256), 1)
		death_tween.tween_callback(func(): get_tree().reload_current_scene())
