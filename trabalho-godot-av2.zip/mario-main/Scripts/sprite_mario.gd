extends AnimatedSprite2D

class_name PlayerAnimatedSprite
var esta_agachado = false
func trigger_animation(velocity: Vector2, direction: float, player_mode: Player.PlayerMode, is_crouching: bool):
	if is_crouching:
		if not esta_agachado: 
			play("TESTE_AGACHADO")
			await animation_finished 
			esta_agachado = true
		play("TESTE_AGACHADOPARADO")
		return
	else:
		esta_agachado = false

	var animation_prefix = Player.PlayerMode.keys()[player_mode].to_snake_case()

	if direction != 0:
		flip_h = direction < 0

	if not get_parent().is_on_floor():
		if not is_playing() or animation != "TESTE_DOUBLEJUMP":
			play("TESTE_PULO")
	elif abs(velocity.x) > 10:
		play("TESTE_CORRENDO")
	else:
		play("TESTE_IDLE")
