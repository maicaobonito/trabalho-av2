extends Node


func _on_hit_lava_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		body.die()
		$hit_Lava/colisao_Lava.set_deferred("disabled", true)


func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		get_tree().change_scene_to_file("res://fase_1.tscn")
